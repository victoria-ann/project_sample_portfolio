-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 02, 2024 at 06:18 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `final_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `abnormality_type`
--

CREATE TABLE `abnormality_type` (
  `abnormality_type_id` int(1) NOT NULL,
  `abnormality_name` varchar(20) NOT NULL,
  `abnormality_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `abnormality_type`
--

INSERT INTO `abnormality_type` (`abnormality_type_id`, `abnormality_name`, `abnormality_desc`) VALUES
(1, 'MYC Rearrangement', 'MYC gene region is separated'),
(2, 'BCL2 Rearrangement', 'BCL2 gene region is separated'),
(3, 'BCL6 Rearrangement', 'BCL6 gene region is separated');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis_type`
--

CREATE TABLE `diagnosis_type` (
  `diagnosis_type_id` int(1) NOT NULL,
  `diagnosis_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diagnosis_type`
--

INSERT INTO `diagnosis_type` (`diagnosis_type_id`, `diagnosis_name`) VALUES
(1, 'Double Hit Lymphoma'),
(2, 'Triple Hit Lymphoma');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` int(11) NOT NULL,
  `hospital_name` varchar(40) NOT NULL,
  `hospital_location` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `hospital_name`, `hospital_location`) VALUES
(1, 'Johns Hopkins Hospital', 'Baltimore, Maryland'),
(2, 'Massachusetts General Hospital', 'Boston, Massachusetts'),
(3, 'Mayo Clinic', 'Rochester, Minnesota'),
(4, 'Cleveland Clinic', 'Cleveland, Ohio'),
(5, 'Stanford Health Care', 'Stanford, California'),
(8, 'Cedar-Sinai', 'Los Angeles, California'),
(9, 'Stanford HealthCare', 'Standord California'),
(12, 'UCSF Medical Center', 'San Francisco, California'),
(13, 'Northwestern Memorial Hospital', 'Chicago, Illinois'),
(14, 'Beaumont Hospital', 'Royal Oak, Michigan'),
(16, 'University of Utah Hospital', 'Salt Lake City, Utah'),
(17, 'Yale New Haven Hospital', 'New Haven, Connecticut'),
(18, 'Aurora Medical Center', 'Green Bay, Wisconsin'),
(19, 'Gunderson Health Systems', 'La Crosse, Wisconsin'),
(20, 'Fairview Medical Center', 'Burnsville, Minnesota'),
(21, 'Bellin Health', 'Appleton, Wisconsin'),
(22, 'Hospital of North Dakota', 'Fargo, North Dakota'),
(23, 'Austin Hospital', 'Austin, Texas'),
(24, 'Jackson Hospital', 'Jacksonville, Florida'),
(25, 'Miriam Hospital', 'Providence, Rhode Island'),
(26, 'Duke University Hospital', 'Durham, North Carolina'),
(27, 'Brgham and Women\'s Hosptial', 'Boston, Massachusetts');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(20) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `demographic_info` varchar(50) NOT NULL,
  `hospital_hospital_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `age`, `gender`, `demographic_info`, `hospital_hospital_id`) VALUES
(6, 45, 'Male', 'White', 1),
(7, 52, 'Female', 'Hispanic or Latino', 2),
(8, 60, 'Male', 'Black or African American', 3),
(9, 16, 'Female', 'Asian', 4),
(10, 55, 'Male', 'American Native or Alaska Native', 5),
(11, 71, 'Male', 'White', 3),
(12, 81, 'Female', 'Hispanic or Latino', 8),
(13, 34, 'Female', 'Black or African American', 8),
(14, 23, 'Female', 'Middle Eastern or North African', 1),
(15, 65, 'Male', 'White', 2),
(16, 60, 'Female', 'White', 16),
(17, 81, 'Male', 'Native Hawaiian or Other Pacific Islander', 12),
(18, 75, 'Female', 'Asian', 14),
(19, 63, 'Male', 'Black or African American', 13),
(20, 77, 'Female', 'Black or African American', 18),
(21, 65, 'Male', 'Middle Eastern or North African', 17),
(22, 70, 'Male', 'Hispanic or Latino', 25),
(23, 45, 'Female', 'White', 3),
(24, 15, 'Female', 'Black or African American', 1),
(25, 65, 'Male', 'White', 18),
(26, 61, 'Male', 'Asian', 3),
(27, 54, 'Female', 'Native Hawaiian or Other Pacific Islander', 17),
(28, 54, 'Male', 'Hispanic or Latino', 12),
(29, 60, 'Male', 'Hispanic or Latino', 18);

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE `provider` (
  `provider_id` int(10) NOT NULL,
  `provider_name` varchar(40) NOT NULL,
  `specialty` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `hospital_hospital_id1` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`provider_id`, `provider_name`, `specialty`, `username`, `password`, `hospital_hospital_id1`) VALUES
(2, 'Dakota Erins', 'Oncology', 'dakota.erins', '47f7d821cad2070ebef455e5d0506d6d944bb2cb', 8),
(3, 'Arthur Smith', 'Pathology', 'arthur.smith', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 3),
(4, 'Jordan Gonzalez', 'Oncology', 'jordan.gonzalez', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 1),
(5, 'Jane Johnson', 'Pathology', 'jane.johnson', 'db486703d850a9b450eb125b67c8f274927a97e8', 2),
(6, 'Samantha Miller', 'Oncology', 'samantha.miller', 'f95a7535e09c1654990cc536a53a14dd16b63770', 4),
(10, 'Craig Evens', 'Oncology', 'craig.evens', '50624776624f802509bbe4469abd671d4be6cad4', 5),
(11, 'Carrie', 'Rodgers', 'carrie.rodgers', 'd6a2a26a046da5372e625ac4b49e1e7f92a0cddf', 12),
(12, 'Allen James', 'Oncology', 'allen.james', '2abd55e001c524cb2cf6300a89ca6366848a77d5', 13),
(13, 'Claire Nelson', 'Oncology', 'claire.nelson', '405928ee9a480fc2a8eade49b14a897e6af33c76', 14),
(14, 'Elaine Clark', 'Oncology', 'elaine.clark', 'cb129d1d3b49b6c3df1377ba1d479523d8e5a559', 16),
(15, 'Kyle Jennings', 'Oncology', 'kyle.jennings', 'd594c2cc0a53025004791399d80e20852af4c988', 17),
(16, 'Ryan Gilbert', 'Pathology', 'ryan.gilbert', 'ff9e43337e6af8ab422c86c86b5c7f99375bf5c0', 18),
(17, 'Aaron Stevens', 'Oncology', 'aaron.stevens', '3fa4054f214f0f8063d8fb4453be65d460e3e30c', 19),
(18, 'Jason Stephens', 'Oncology', 'jason.stephens', '85777c03b72554cd08e721b6148dc27d2a50a7a6', 24),
(19, 'Michelle Campbell', 'Oncology', 'michelle.campbell', 'fd0f0750a4bfbf923ba767a31952aea8f613affe', 25),
(20, 'Anya Jones', 'Oncology', 'anya.jones', 'e5fd9cfe0e8039111d54b588e77b2bb0cad41c3a', 26),
(21, 'Mary Hunt', 'Oncology', 'mary.hunt', '98f54143ab4e86b28c3afee0f50f2f51cfb2ed38', 27);

-- --------------------------------------------------------

--
-- Table structure for table `tumor_info`
--

CREATE TABLE `tumor_info` (
  `tumor_info_id` int(20) NOT NULL,
  `tissue_type` varchar(40) NOT NULL,
  `patient_patient_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tumor_info`
--

INSERT INTO `tumor_info` (`tumor_info_id`, `tissue_type`, `patient_patient_id`) VALUES
(21, 'Inguinal lymph node', 6),
(22, 'Axillary lymph node', 7),
(23, 'Brain', 8),
(24, 'Liver', 9),
(25, 'Breast', 10),
(26, 'Spleen', 11),
(27, 'Submandibular Lymph Node', 12),
(28, 'Inguinal Lymph Node', 13),
(36, 'Axillary Lymph Node', 14),
(37, 'Stomach', 15),
(38, 'Retroperitonium', 16),
(39, 'Stomach', 17),
(40, 'Axillary Lymph Node', 18),
(41, 'Retroperitonium ', 20),
(42, 'Brain', 21),
(43, 'Inguinal Lymph Node', 22),
(44, '', 22),
(45, 'Spleen', 23),
(46, 'Brain', 24),
(47, 'Axillary Lymph Node', 26),
(48, 'Axillary Lymph Node', 26),
(49, 'Liver', 27),
(50, 'inguinal Lymph Node', 28);

-- --------------------------------------------------------

--
-- Table structure for table `tumor_info_diagnosis_type`
--

CREATE TABLE `tumor_info_diagnosis_type` (
  `tumor_info_tumor_info_id` int(20) NOT NULL,
  `diagnosis_type_diagnosis_type_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tumor_info_diagnosis_type`
--

INSERT INTO `tumor_info_diagnosis_type` (`tumor_info_tumor_info_id`, `diagnosis_type_diagnosis_type_id`) VALUES
(21, 2),
(22, 1),
(23, 1),
(26, 1),
(27, 1),
(28, 2),
(36, 1),
(39, 2),
(41, 2),
(42, 1),
(43, 1),
(45, 2),
(47, 1),
(48, 1),
(49, 2),
(50, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tumor_patient_abnormality`
--

CREATE TABLE `tumor_patient_abnormality` (
  `abnormality_type_abnormality_type_id` int(20) NOT NULL,
  `tumor_info_tumor_info_id` int(20) NOT NULL,
  `tumor_info_patient_patient_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tumor_patient_abnormality`
--

INSERT INTO `tumor_patient_abnormality` (`abnormality_type_abnormality_type_id`, `tumor_info_tumor_info_id`, `tumor_info_patient_patient_id`) VALUES
(1, 21, 6),
(2, 21, 6),
(3, 21, 6),
(1, 22, 7),
(2, 22, 7),
(2, 23, 8),
(3, 23, 8),
(1, 24, 9),
(3, 25, 10),
(1, 26, 11),
(2, 26, 11),
(1, 27, 12),
(3, 27, 12),
(1, 28, 13),
(2, 28, 13),
(3, 28, 13),
(2, 36, 14),
(3, 36, 14),
(1, 37, 15),
(2, 38, 16),
(1, 39, 17),
(2, 39, 17),
(3, 39, 17),
(3, 40, 18),
(1, 41, 20),
(2, 41, 20),
(3, 41, 20),
(1, 42, 21),
(2, 42, 21),
(2, 43, 22),
(3, 43, 22),
(3, 43, 22),
(3, 44, 22),
(1, 45, 23),
(2, 45, 23),
(3, 45, 23),
(3, 43, 22),
(3, 44, 22),
(1, 46, 24),
(1, 47, 26),
(3, 47, 26),
(1, 47, 26),
(1, 48, 26),
(3, 47, 26),
(3, 48, 26),
(1, 49, 27),
(2, 49, 27),
(3, 49, 27),
(2, 50, 28),
(3, 50, 28);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abnormality_type`
--
ALTER TABLE `abnormality_type`
  ADD PRIMARY KEY (`abnormality_type_id`);

--
-- Indexes for table `diagnosis_type`
--
ALTER TABLE `diagnosis_type`
  ADD PRIMARY KEY (`diagnosis_type_id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospital_id`),
  ADD UNIQUE KEY `Uni_hospital` (`hospital_name`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`),
  ADD KEY `hospital_id_fk` (`hospital_hospital_id`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`provider_id`),
  ADD UNIQUE KEY `Uni_username` (`username`),
  ADD UNIQUE KEY `Uni_password` (`password`),
  ADD KEY `hospital_id_fk1` (`hospital_hospital_id1`);

--
-- Indexes for table `tumor_info`
--
ALTER TABLE `tumor_info`
  ADD PRIMARY KEY (`tumor_info_id`),
  ADD KEY `patient_id_fk` (`patient_patient_id`);

--
-- Indexes for table `tumor_info_diagnosis_type`
--
ALTER TABLE `tumor_info_diagnosis_type`
  ADD KEY `tumor_info_fk` (`tumor_info_tumor_info_id`),
  ADD KEY `diagnosis_type_fk` (`diagnosis_type_diagnosis_type_id`);

--
-- Indexes for table `tumor_patient_abnormality`
--
ALTER TABLE `tumor_patient_abnormality`
  ADD KEY `abnormality_type_fk` (`abnormality_type_abnormality_type_id`),
  ADD KEY `tumor_info_fk1` (`tumor_info_tumor_info_id`),
  ADD KEY `tumor_info_patient_id_fk` (`tumor_info_patient_patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hospital_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `provider`
--
ALTER TABLE `provider`
  MODIFY `provider_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tumor_info`
--
ALTER TABLE `tumor_info`
  MODIFY `tumor_info_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `hospital_id_fk` FOREIGN KEY (`hospital_hospital_id`) REFERENCES `hospital` (`hospital_id`);

--
-- Constraints for table `provider`
--
ALTER TABLE `provider`
  ADD CONSTRAINT `hospital_id_fk1` FOREIGN KEY (`hospital_hospital_id1`) REFERENCES `hospital` (`hospital_id`);

--
-- Constraints for table `tumor_info`
--
ALTER TABLE `tumor_info`
  ADD CONSTRAINT `patient_id_fk` FOREIGN KEY (`patient_patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `tumor_info_diagnosis_type`
--
ALTER TABLE `tumor_info_diagnosis_type`
  ADD CONSTRAINT `diagnosis_type_fk` FOREIGN KEY (`diagnosis_type_diagnosis_type_id`) REFERENCES `diagnosis_type` (`diagnosis_type_id`),
  ADD CONSTRAINT `tumor_info_fk` FOREIGN KEY (`tumor_info_tumor_info_id`) REFERENCES `tumor_info` (`tumor_info_id`);

--
-- Constraints for table `tumor_patient_abnormality`
--
ALTER TABLE `tumor_patient_abnormality`
  ADD CONSTRAINT `abnormality_type_fk` FOREIGN KEY (`abnormality_type_abnormality_type_id`) REFERENCES `abnormality_type` (`abnormality_type_id`),
  ADD CONSTRAINT `tumor_info_fk1` FOREIGN KEY (`tumor_info_tumor_info_id`) REFERENCES `tumor_info` (`tumor_info_id`),
  ADD CONSTRAINT `tumor_info_patient_id_fk` FOREIGN KEY (`tumor_info_patient_patient_id`) REFERENCES `tumor_info` (`patient_patient_id`);
