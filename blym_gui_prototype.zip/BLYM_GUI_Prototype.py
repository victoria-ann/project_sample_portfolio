##### Using Only One Window #####
# After logging in, switch to the main window
# What will essentially happen is the login window is cleared and the multi-tabbed window is displayed

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import pymysql
import db_functions as db

# Create each frame as a class, i.e., a class for the login frame and a class for viewing tumor window

class LoginFrame(tk.Frame): # Create a class for the login frame
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.master.title("Solid Tumor BLYM Database Login/Registration")
        self.master.geometry("600x500")

        self.tab_parent = ttk.Notebook(self.master)

        tab1 = ttk.Frame(self.tab_parent)
        tab2 = ttk.Frame(self.tab_parent)
        self.tab_parent.add(tab1, text="Login")
        self.tab_parent.add(tab2, text="Register")

        #ELEMENTS FOR TAB 1 --- LOGIN
        #====== search button  ==========
        self.username = tk.StringVar()
        self.passw = tk.StringVar()

        # === widgets for TAB ONE

        UsernameLabelTabOne = tk.Label(tab1, text="username: ").grid(row=1, column=0, padx=15, pady=15)
        PasswordLabelTabOne = tk.Label(tab1, text="password: ").grid(row=2, column=0, padx=15, pady=15)

        UsernameEntryTabOne = tk.Entry(tab1, textvariable=self.username).grid(row=1, column=1, padx=15, pady=15)
        PasswordEntryTabOne = tk.Entry(tab1, textvariable=self.passw, show="*").grid(row=2, column=1, padx=15, pady=15)

        buttonLogin = tk.Button(tab1, text="Login", command=self.login).grid(row=3, column=1, padx=15, pady=15)


        #ELEMENTS FOR TAB 2 --- REGISTER
        #====== search button  ==========
        self.usernameReg = tk.StringVar()
        self.passwReg = tk.StringVar()
        self.nameTabTwo = tk.StringVar()
        self.specialtyTabTwo = tk.StringVar()
        self.institutionTabTwo = tk.StringVar()
        self.institutlocTabTwo = tk.StringVar()
        # === widgets for TAB ONE

        nameLabelTabTwo = ttk.Label(tab2, text='First and Last Name').grid(row=0, column=0, padx=15, pady=15)
        specialtyLabelTabTwo = ttk.Label(tab2, text='Specialty').grid(row=1, column=0, padx=15, pady=15)
        institutionLabelTabTwo = ttk.Label(tab2, text='Institution Name').grid(row=2, column=0, padx=15, pady=15)
        institutlocLabelTabTwo = ttk.Label(tab2, text='Institution Location\n (ex) Houston, Texas)').grid(row=3, column=0, padx=15, pady=15)
        usernameLabelTabTwo = tk.Label(tab2, text="Username").grid(row=4, column=0, padx=15, pady=15)
        passwordLabelTabTwo = tk.Label(tab2, text="Password").grid(row=5, column=0, padx=15, pady=15)

        nameEntryTabTwo = ttk.Entry(tab2, textvariable=self.nameTabTwo).grid(row=0, column=1, padx=15, pady=15)
        specialtyEntryTabTwo = ttk.Entry(tab2, textvariable=self.specialtyTabTwo).grid(row=1, column=1, padx=15, pady=15)
        institutionEntryTabTwo = ttk.Entry(tab2, textvariable=self.institutionTabTwo).grid(row=2, column=1, padx=15, pady=15)
        institutlocEntryTabTwo = ttk.Entry(tab2, textvariable=self.institutlocTabTwo).grid(row=3, column=1, padx=15, pady=15)
        usernameEntryTabTwo = tk.Entry(tab2, textvariable=self.usernameReg).grid(row=4, column=1, padx=15, pady=15)
        passwordEntryTabTwo = tk.Entry(tab2, textvariable=self.passwReg, show="*").grid(row=5, column=1, padx=15, pady=15)

        buttonRegister = tk.Button(tab2, text="Register", command=self.register).grid(row=6, column=1, padx=15, pady=15)

        self.tab_parent.pack(expand=1, fill='both')


    # Add the login function within the LoginFrame class
    def database_error(self, err):
            messagebox.showinfo("Error", err)
            return False

    def test_registration_input(self):
        empty_textbox_login = 0

        if self.nameTabTwo.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.specialtyTabTwo.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.institutionTabTwo.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.institutlocTabTwo.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.usernameReg.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.passwReg.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if empty_textbox_login > 0:
            raise Exception("empty textbox")

    def db_register(self):
        try:
            con = db.open_database()
        except db.DatabaseError as e:
            raise Exception("Cannot open Database")
        try:
            self.test_registration_input()
        except Exception as e:
            raise Exception("empty input boxes")
        else:
            try:
                sql = "SELECT * FROM provider WHERE `username` = %s"
                values = (self.usernameReg.get())
                num_of_rows, rows = db.query_database(con, sql, values)
                print("num_of_rows:", num_of_rows)
            except Exception:
                raise Exception("Error querying the database")
            if num_of_rows == 1:
                raise Exception("username already exists")
            else:
                try:
                    con = db.open_database()

                    sql_check_hospital = "SELECT hospital_id FROM hospital WHERE hospital_name = %s AND hospital_location = %s;"
                    vals_check_hospital = (self.institutionTabTwo.get(), self.institutlocTabTwo.get())
                    num_of_rows, hospital_id = db.query_database(con, sql_check_hospital, vals_check_hospital)

                    if num_of_rows == 0:
                        con = db.open_database()

                        sql_insert_hospital = ("INSERT INTO hospital (hospital_name, hospital_location)"
                                               "VALUES (%s, %s);")
                        vals_insert_hospital = (self.institutionTabTwo.get(), self.institutlocTabTwo.get())
                        self.master.insert_database(con, sql_insert_hospital, vals_insert_hospital)


                    con = db.open_database()
                    num_of_rows, hospital_id = db.query_database(con, sql_check_hospital, vals_check_hospital)
                    hospital_id = hospital_id[0][0]
                    sql_provider = (
                        "INSERT INTO provider (provider_name, specialty, username, password, hospital_hospital_id1) "
                        "VALUES (%s, %s, %s, SHA(%s), %s);")
                    vals_provider = (
                        self.nameTabTwo.get(), self.specialtyTabTwo.get(), self.usernameReg.get(),
                        self.passwReg.get(), hospital_id)
                    con = db.open_database()
                    self.master.insert_database(con, sql_provider, vals_provider)


                except Exception as e:
                    messagebox.showinfo("Error inserting data", e)
                else:
                    print("Registration successful")

    def register(self):

        try:
            self.db_register()
        except Exception as e:
            print(e)
            self.database_error("Error registering new user")
        else:
            messagebox.showinfo("ProviderDB", "New provider registered")

    ############ FUNCTIONS FOR LOGIN ##################
    def test_login_input(self):
        empty_textbox_login = 0
        if self.username.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if self.passw.get() == "":
            empty_textbox_login = empty_textbox_login + 1
        if empty_textbox_login > 0:
            raise Exception("empty textbox")

    def testcredentials(self):
        con = None
        try:
            con = db.open_database()
        except db.DatabaseError as e:
            raise Exception("Cannot open Database")

        try:
            self.test_login_input()
        except Exception as e:
            raise Exception("empty input boxes")
        else:
            try:
                sql = "SELECT * FROM provider where `username` = %s and  `password`= SHA(%s)"
                values = (self.username.get(), self.passw.get())
                num_of_rows, rows = db.query_database(con, sql, values)
            except Exception:
                raise Exception("Error querying the database")
            else:
                if num_of_rows == 1:
                    return True
                else:
                    raise Exception("wrong username and/or password")
                    return False
                
    def login(self):
        try:
            success = self.testcredentials()
        except Exception as e:
            self.database_error(e)

        # if correct, switch to the main window
        if success:
            self.master.switch_frame(TumorWindow, self.tab_parent)
        else:
            pass
    def _quit(self):
        self.quit()  # stops mainloop
        self.destroy()


class TumorWindow(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        master.title("Solid Tumor BLYM Database")
        master.geometry("1500x700")
        self.patient_ids = []
        self.create_widgets()

       
    def on_tab_selected(self, event):
        selected_tab = event.widget.select()
        tab_text = event.widget.tab(selected_tab, 'text')

        if tab_text == 'Manage Patient Info':
            print("Manage Patient Info tab selected")
            if self.master.blank_textboxes_tab_three == False:
                self.load_patient_info_results()
        elif tab_text == "Add New Patient":
            print("Add New Patient Tab Selected")
            self.master.blank_textboxes_tab_three = True
        elif tab_text == 'Manage Tumor Info':
            print("Manage Tumor Info tab selected")
            if self.master.blank_textboxes_tab_four == False:
                self.load_tumor_info_results()
        elif tab_text == "Add New Tumor":
            print("Add New Tumor Tab Selected")
            self.master.blank_textboxes_tab_four = True

    def exitButtonClicked(self):
        print("Exit button clicked!")
        res = messagebox.askquestion('ask', "Are you sure?")
        if res.lower() == 'yes':
            self.master.destroy()
        else:
            messagebox.showinfo('return', 'Returning to main app.')

    def load_patient_info_results(self):
        # Connect to DB
        try:
            con = db.open_database()
        except Exception as e:
            messagebox.showinfo("Database connection error", e)
            exit()

        messagebox.showinfo("Connection", "DB connection ok")

        # Retrieve data from DB
        try:
            sql = """
                SELECT 
                    p.patient_id, p.age, p.gender, p.demographic_info, h.hospital_name, h.hospital_location
                FROM 
                    patient p
                JOIN 
                    hospital h ON p.hospital_hospital_id = h.hospital_id"""
            self.num_of_rows, self.rows = db.query_database(con, sql, None)
            print("num_of_rows:", self.num_of_rows)
            print("rows:", self.rows)
            return True
        except db.DatabaseError as e:
            messagebox.showinfo("Error querying the DB", e)
            return False

    def load_tumor_info_results(self):
        # Connect to DB
        try:
            con = db.open_database()
        except Exception as e:
            messagebox.showinfo("Database connection error", e)
            exit()

        # Retrieve data from DB
        try:
            sql = """
                SELECT ti.tumor_info_id, ti.tissue_type, dt.diagnosis_name, h.hospital_name, h.hospital_location, GROUP_CONCAT(at.abnormality_name SEPARATOR ', ') AS abnormalities
                FROM tumor_info AS ti
                JOIN patient AS p ON ti.patient_patient_id = p.patient_id
                JOIN hospital AS h ON p.hospital_hospital_id = h.hospital_id
                LEFT JOIN tumor_info_diagnosis_type AS tidt ON ti.tumor_info_id = tidt.tumor_info_tumor_info_id
                LEFT JOIN diagnosis_type AS dt ON tidt.diagnosis_type_diagnosis_type_id = dt.diagnosis_type_id
                LEFT JOIN tumor_patient_abnormality AS tpa ON ti.tumor_info_id = tpa.tumor_info_tumor_info_id AND ti.patient_patient_id = tpa.tumor_info_patient_patient_id
                LEFT JOIN abnormality_type AS at ON tpa.abnormality_type_abnormality_type_id = at.abnormality_type_id
                GROUP BY ti.tumor_info_id, ti.tissue_type, dt.diagnosis_name, h.hospital_name, h.hospital_location;
                """
            self.num_of_rows, self.rows1 = db.query_database(con, sql, None)
            print("num_of_rows:", self.num_of_rows)
            print("rows:", self.rows1)
            return True
        except db.DatabaseError as e:
            messagebox.showinfo("Error querying the DB", e)
            return False

    def database_error(self, err):
        messagebox.showinfo("Error", err)
        return False


    def insert_into_patient(self,age, gender, demographic_info, hospital_name, hospital_location):

        try:
            con = db.open_database()

            sql_patient = (
                "INSERT INTO patient (age, gender, demographic_info, hospital_hospital_id) "
                "SELECT %s, %s, %s, hospital_id FROM hospital WHERE hospital_name = %s and hospital_location = %s;")
            vals_patient = (age, gender, demographic_info, hospital_name, hospital_location)
            self.master.insert_database(con, sql_patient, vals_patient)

        except Exception as e:
            messagebox.showinfo("Error inserting data", e)

        finally:
            if con:
                con.close()

    def load_db_menu_patient_id(self):
        try:
            con = db.open_database()
        except Exception as e:
            messagebox.showinfo("Database error", e)
            exit()

        try:
            sql = "SELECT patient_id FROM patient ORDER BY patient_id ASC"
            menu_num_of_rows, m_rows = db.query_database(con, sql, None)
            self.patient_ids = [row[0] for row in m_rows]
            print("patient_ids:", self.patient_ids)
        except db.DatabaseError:
            messagebox.showinfo("Error querying the DB")

        return self.patient_ids

    def scroll_forward_tab1(self):

        if self.master.row_counter >= (self.num_of_rows - 1):
            messagebox.showinfo("DB error", "End of DB")
        else:
            self.master.row_counter = self.master.row_counter + 1
            self.idTabOne.set(self.rows[self.master.row_counter][0])
            self.ageTabOne.set(self.rows[self.master.row_counter][1])
            self.genderTabOne.set(self.rows[self.master.row_counter][2])
            self.optionsVar.set(self.rows[self.master.row_counter][3])
            self.hosnameTabOne.set(self.rows[self.master.row_counter][4])
            self.hoslocationTabOne.set(self.rows[self.master.row_counter][5])
        print(self.mycTabFour.get())

    def scroll_backward_tab1(self):

        if self.master.row_counter == 0:
            messagebox.showinfo("DB error", "Start of DB")
        else:
            self.master.row_counter = self.master.row_counter - 1
            self.idTabOne.set(self.rows[self.master.row_counter][0])
            self.ageTabOne.set(self.rows[self.master.row_counter][1])
            self.genderTabOne.set(self.rows[self.master.row_counter][2])
            self.optionsVar.set(self.rows[self.master.row_counter][3])
            self.hosnameTabOne.set(self.rows[self.master.row_counter][4])
            self.hoslocationTabOne.set(self.rows[self.master.row_counter][5])

    def scroll_forward_tab2(self):

        if self.master.row_counter >= (self.num_of_rows - 1):
            messagebox.showinfo("DB error", "End of DB")
        else:
            self.master.row_counter = self.master.row_counter + 1
            self.tissueTabTwo.set(self.rows1[self.master.row_counter][1])
            self.diagnosisTabTwo.set(self.rows1[self.master.row_counter][2])
            self.hosnameTabTwo.set(self.rows1[self.master.row_counter][3])
            self.hoslocationTabTwo.set(self.rows1[self.master.row_counter][4])
            if "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL2 Rearrangement" in self.rows1[self.master.row_counter][
                5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL2 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
            elif "BCL2 Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(0)
                self.bcl6TabTwo.set(1)
                self.bcl2TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(0)
                self.bcl6TabTwo.set(1)
            elif self.rows1[self.master.row_counter][5] == "MYC Rearrangement":
                self.mycTabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.bcl2TabTwo.set(0)
            elif self.rows1[self.master.row_counter][5] == "BCL2 Rearrangement":
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.mycTabTwo.set(0)
            elif self.rows1[self.master.row_counter][5] == "BCL6 Rearrangement":
                self.bcl6TabTwo.set(1)
                self.mycTabTwo.set(0)
                self.bcl2TabTwo.set(0)

    def scroll_backward_tab2(self):

        if self.master.row_counter == 0:
            messagebox.showinfo("DB error", "Start of DB")
        else:
            self.master.row_counter = self.master.row_counter - 1
            self.tissueTabTwo.set(self.rows1[self.master.row_counter][1])
            self.diagnosisTabTwo.set(self.rows1[self.master.row_counter][2])
            self.hosnameTabTwo.set(self.rows1[self.master.row_counter][3])
            self.hoslocationTabTwo.set(self.rows1[self.master.row_counter][4])
            if "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL2 Rearrangement" in self.rows1[self.master.row_counter][
                5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL2 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
            elif "BCL2 Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(0)
                self.bcl6TabTwo.set(1)
                self.bcl2TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[self.master.row_counter][5] and "BCL6 Rearrangement" in self.rows1[self.master.row_counter][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(0)
                self.bcl6TabTwo.set(1)
            elif self.rows1[self.master.row_counter][5] == "MYC Rearrangement":
                self.mycTabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.bcl2TabTwo.set(0)
            elif self.rows1[self.master.row_counter][5] == "BCL2 Rearrangement":
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.mycTabTwo.set(0)
            elif self.rows1[self.master.row_counter][5] == "BCL6 Rearrangement":
                self.bcl6TabTwo.set(1)
                self.mycTabTwo.set(0)
                self.bcl2TabTwo.set(0)

    def add_new_patient(self):
        self.master.blank_textboxes_tab_three
        blank_textbox_count = 0

        if self.ageTabThree.get() == "":
            blank_textbox_count = blank_textbox_count + 1
        if self.genderTabThree.get() == "":
            blank_textbox_count = blank_textbox_count + 1
        if self.optionsVarThree.get() == "Select Race/Ethnicity":
            blank_textbox_count = blank_textbox_count + 1
        if self.hosnameTabThree.get() == "":
            blank_textbox_count = blank_textbox_count + 1
        if self.hoslocationTabThree.get() == "":
            blank_textbox_count = blank_textbox_count + 1
        if blank_textbox_count > 0:
            self.master.blank_textboxes_tab_three = True
            messagebox.showinfo("Database Error", "Blank Text Boxes")
        elif blank_textbox_count == 0:
            self.master.blank_textboxes_tab_three = False
            try:
                self.insert_into_patient(self.ageTabThree.get(), self.genderTabThree.get(), self.optionsVarThree.get(),
                                    self.hosnameTabThree.get(), self.hoslocationTabThree.get())
                self.load_db_menu_patient_id()
            except Exception as e:
                messagebox.showinfo("Database Error", e)
            else:
                messagebox.showinfo("Database", "Patient Record Added to Database")

    def insert_into_tumor(self, tissue_type, patient_id, diagnosis_type):

                try:
                    con = db.open_database()

                    sql_tumor_info = (
                        "INSERT INTO tumor_info (`tissue_type`, `patient_patient_id`)"
                        "VALUES (%s, %s);")
                    vals_tumor_info = (tissue_type, patient_id)
                    self.master.insert_database(con, sql_tumor_info, vals_tumor_info)

                    sql_tumor_info_diagnosis_type = (
                        "INSERT INTO tumor_info_diagnosis_type (`tumor_info_tumor_info_id`, `diagnosis_type_diagnosis_type_id`)"
                        "SELECT LAST_INSERT_ID(), diagnosis_type_id FROM diagnosis_type WHERE diagnosis_name = %s;")
                    vals_tumor_info_diagnosis_type = (diagnosis_type)
                    self.master.insert_database(con, sql_tumor_info_diagnosis_type, vals_tumor_info_diagnosis_type)

                    if (self.mycTabFour.get()) == 1:
                        sql_tumor_patient_abnormality = (
                            '''INSERT INTO `tumor_patient_abnormality` (`abnormality_type_abnormality_type_id`, `tumor_info_tumor_info_id`, `tumor_info_patient_patient_id`)
                            SELECT 
                                1 AS `abnormality_type_abnormality_type_id`,
                                ti.`tumor_info_id` AS `tumor_info_tumor_info_id`,
                                p.`patient_id` AS `tumor_info_patient_patient_id`
                            FROM 
                                `tumor_info` ti
                            INNER JOIN 
                                `patient` p ON ti.`patient_patient_id` = p.`patient_id`
                            WHERE 
                                p.`patient_id` = %s;''')
                        vals_tumor_patient_abnormality = (patient_id)
                        self.master.insert_database(con, sql_tumor_patient_abnormality, vals_tumor_patient_abnormality)

                    if (self.bcl2TabFour.get()) == 1:
                        sql_tumor_patient_abnormality = (
                            '''INSERT INTO `tumor_patient_abnormality` (`abnormality_type_abnormality_type_id`, `tumor_info_tumor_info_id`, `tumor_info_patient_patient_id`)
                            SELECT 
                                2 AS `abnormality_type_abnormality_type_id`,
                                ti.`tumor_info_id` AS `tumor_info_tumor_info_id`,
                                p.`patient_id` AS `tumor_info_patient_patient_id`
                            FROM 
                                `tumor_info` ti
                            INNER JOIN 
                                `patient` p ON ti.`patient_patient_id` = p.`patient_id`
                            WHERE 
                                p.`patient_id` = %s;''')
                        vals_tumor_patient_abnormality = (patient_id)
                        self.master.insert_database(con, sql_tumor_patient_abnormality, vals_tumor_patient_abnormality)

                    if (self.bcl6TabFour.get()) == 1:
                        sql_tumor_patient_abnormality = (
                            '''INSERT INTO `tumor_patient_abnormality` (`abnormality_type_abnormality_type_id`, `tumor_info_tumor_info_id`, `tumor_info_patient_patient_id`)
                            SELECT 
                                3 AS `abnormality_type_abnormality_type_id`,
                                ti.`tumor_info_id` AS `tumor_info_tumor_info_id`,
                                p.`patient_id` AS `tumor_info_patient_patient_id`
                            FROM 
                                `tumor_info` ti
                            INNER JOIN 
                                `patient` p ON ti.`patient_patient_id` = p.`patient_id`
                            WHERE 
                                p.`patient_id` = %s;''')
                        vals_tumor_patient_abnormality = (patient_id)
                        self.master.insert_database(con, sql_tumor_patient_abnormality, vals_tumor_patient_abnormality)

                except Exception as e:
                    messagebox.showinfo("Error inserting data", e)

                finally:
                    self.update_option_menu()
                    if con:
                        con.close()

    def add_new_tumor(self):
        blank_textbox_count = 0

        if self.tissueTabFour.get() == "":
            blank_textbox_count += 1
        if self.patient_var_TabFour.get() == "Select Patient ID":
            blank_textbox_count += 1

        if blank_textbox_count > 0:
            self.master.blank_textboxes_tab_four = True
            messagebox.showinfo("Database Error", "Blank Text Boxes")
        else:
            self.master.blank_textboxes_tab_four = False
            try:
                self.insert_into_tumor(self.tissueTabFour.get(), self.patient_var_TabFour.get(), self.diagnosisTabFour.get())
            except Exception as e:
                messagebox.showinfo("Database Error", e)
            else:
                messagebox.showinfo("Database", "Tumor Record Added to Database")
            
    def display_query_results(self):
        self.criteria = []

        # connect to DB
        try:
            con = db.open_database()
        except (Exception) as e:
            messagebox.showinfo("Database connection error")
            exit()

        # Use this so I can group my abnormalities while still using a SELECT statement
        sql = "SET SESSION sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))"
        cursor = con.cursor()
        cursor.execute(sql)

        # retrieve data from DB based search criteria
        try:
            id_val = self.idTabFive.get()
            age_val = self.ageTabFive.get()
            gender_val = self.genderTabFive.get()
            tissue_val = self.tissueTabFive.get()
            diagnosis_val = self.diagnosisTabFive.get()
            hosname_val = self.hosnameTabFive.get()
            hoslocation_val = self.hoslocationTabFive.get()
            demo_val = str(self.demographicTabFive.get())

            if (self.mycTabFive.get()) == 1:
                myc_val = "MYC Rearrangement"
                self.criteria.append(myc_val)
            else:
                myc_val = None

            if (self.bcl2TabFive.get()) == 1:
                bcl2_val = "BCL2 Rearrangement"
                self.criteria.append(bcl2_val)
            else:
                bcl2_val = None

            if (self.bcl6TabFive.get()) == 1:
                bcl6_val = "BCL6 rearrangement"
                self.criteria.append(bcl6_val)
            else:
                bcl6_val = None

            if id_val != "":
                self.criteria.append(id_val)
            if age_val != "":
                self.criteria.append(age_val)
            if gender_val != "":
                self.criteria.append(gender_val)
            if tissue_val != "":
                self.criteria.append(tissue_val)
            if diagnosis_val != "Select Diagnosis":
                self.criteria.append(diagnosis_val)
            if hosname_val != "":
                self.criteria.append(hosname_val)
            if hoslocation_val != "":
                self.criteria.append(hoslocation_val)
            if demo_val != "Select Race/Ethnicity":
                self.criteria.append(demo_val)

            sql = """
            SELECT 
                p.patient_id, p.age, p.gender, p.demographic_info, 
                t.tissue_type, GROUP_CONCAT(a.abnormality_name) AS abnormality_names, 
                d.diagnosis_name, h.hospital_name, h.hospital_location
            FROM 
                patient p
            LEFT JOIN 
                tumor_info t ON p.patient_id = t.patient_patient_id
            LEFT JOIN 
                tumor_patient_abnormality ta ON t.tumor_info_id = ta.tumor_info_tumor_info_id
            LEFT JOIN 
                abnormality_type a ON ta.abnormality_type_abnormality_type_id = a.abnormality_type_id
            LEFT JOIN 
                tumor_info_diagnosis_type td ON t.tumor_info_id = td.tumor_info_tumor_info_id
            LEFT JOIN 
                diagnosis_type d ON td.diagnosis_type_diagnosis_type_id = d.diagnosis_type_id
            LEFT JOIN 
                hospital h ON p.hospital_hospital_id = h.hospital_id
            WHERE """

            group_by = """GROUP BY
                p.patient_id, 
                p.age, 
                p.gender, 
                p.demographic_info, 
                t.tissue_type, 
                d.diagnosis_name, 
                h.hospital_name, 
                h.hospital_location;"""

            conditions = []

            if id_val in self.criteria:
                conditions.append("p.patient_id = %s")
            if age_val in self.criteria:
                conditions.append("p.age = %s")
            if gender_val in self.criteria:
                conditions.append("p.gender = %s")
            if tissue_val in self.criteria:
                conditions.append("t.tissue_type = %s")
            if myc_val in self.criteria:
                conditions.append("a.abnormality_name = %s")
            if bcl2_val in self.criteria:
                conditions.append("a.abnormality_name = %s")
            if bcl6_val in self.criteria:
                conditions.append("a.abnormality_name = %s")
            if diagnosis_val in self.criteria:
                conditions.append("d.diagnosis_name = %s")
            if hosname_val in self.criteria:
                conditions.append("h.hospital_name = %s")
            if hoslocation_val in self.criteria:
                conditions.append("h.hospital_location = %s")
            if demo_val in self.criteria:
                conditions.append("p.demographic_info = %s")

            where_clause = " AND ".join(conditions)

            sql += where_clause
            sql += group_by

            print(sql)
            total_rows, my_rows = db.query_database(con, sql, self.criteria)
            print("Search results:")
            print("num_of_rows:", total_rows)
            print("rows:", my_rows)

        except db.DatabaseError:
            messagebox.showinfo("Error querying the DB")

        tableTabFive = ttk.Treeview(self.tab5,
                                     columns=(1, 2, 3, 4, 5, 6, 7, 8, 9),
                                     height=10, show="headings")

        tableTabFive.heading(1, text="Patient ID")
        tableTabFive.heading(2, text="Age")
        tableTabFive.heading(3, text="Gender")
        tableTabFive.heading(4, text="Race/Ethnicity")
        tableTabFive.heading(5, text="Tissue")
        tableTabFive.heading(6, text="Abnormalities")
        tableTabFive.heading(7, text="Diagnosis")
        tableTabFive.heading(8, text="Hospital Name")
        tableTabFive.heading(9, text="Hospital Location")

        tableTabFive.column(1, width=75)
        tableTabFive.column(2, width=50)
        tableTabFive.column(3, width=75)
        tableTabFive.column(4, width=200)
        tableTabFive.column(5, width=150)
        tableTabFive.column(6, width=350)
        tableTabFive.column(7, width=150)
        tableTabFive.column(8, width=200)
        tableTabFive.column(9, width=200)

        tableTabFive.grid(row=7, column=0, columnspan=4, padx=15, pady=15)
     
        if total_rows > 0:
            for row in my_rows:
                tableTabFive.insert('', 'end', values=(row[0], row[1], row[2],
                                                        row[3], row[4], row[5], row[6], row[7], row[8]))
        else:
            messagebox.showinfo("DB Error", "No results")

        return True
    
    def update_option_menu(self):
        self.load_db_menu_patient_id()
        self.patient_var_TabFour = tk.StringVar()
        self.patient_var_TabFour.set("Select Patient ID")
        self.patient_menu_TabFour = tk.OptionMenu(self.tab4, self.patient_var_TabFour, *self.patient_ids)
        self.patient_menu_TabFour.grid(row=0, column=1, padx=15, pady=15)


    
    def create_widgets(self): # Create a function to create the widgets
        
        tab_parent = ttk.Notebook(self.master) # Create a tabbed window

        tab1 = ttk.Frame(tab_parent) # Create a tab for the main window
        tab2 = ttk.Frame(tab_parent)
        tab3 = ttk.Frame(tab_parent)
        self.tab4 = ttk.Frame(tab_parent)
        self.tab5 = ttk.Frame(tab_parent)
        tab6 = ttk.Frame(tab_parent)

        # Binding the Notebook to function def
        tab_parent.bind("<<NotebookTabChanged>>", self.on_tab_selected)
        # Add tabs to tab parent
        tab_parent.add(tab1, text='Manage Patient Info')
        tab_parent.add(tab2, text='Manage Tumor Info')
        tab_parent.add(tab3, text='Add New Patient')
        tab_parent.add(self.tab4, text='Add New Tumor')
        tab_parent.add(self.tab5, text='Search Patient/Tumor')
        tab_parent.add(tab6, text='Logout')

        # place the tabs
        idLabelTabOne = ttk.Label(tab1, text='Patient ID').grid(row=0, column=0, padx=15, pady=15)
        ageLabelTabOne = ttk.Label(tab1, text='Patient Age').grid(row=1, column=0, padx=15, pady=15)
        genderLabelTabOne = ttk.Label(tab1, text='Patient Gender').grid(row=2, column=0, padx=15, pady=15)
        demographicLabelTabOne = ttk.Label(tab1, text='Race/Ethnicity').grid(row=3, column=0, padx=15, pady=15)
        hosnameLabelTabOne = ttk.Label(tab1, text='Hospital Name').grid(row=4, column=0, padx=15, pady=15)
        hoslocationLabelTabOne = ttk.Label(tab1, text='Hospital Location').grid(row=5, column=0, padx=15, pady=15)

        self.idTabOne = tk.StringVar()
        self.ageTabOne = tk.StringVar()
        self.genderTabOne = tk.StringVar()
        self.hosnameTabOne = tk.StringVar()
        self.hoslocationTabOne = tk.StringVar()

        idEntryTabOne = ttk.Entry(tab1, textvariable=self.idTabOne).grid(row=0, column=1, padx=15, pady=15)
        ageEntryTabOne = ttk.Entry(tab1, textvariable=self.ageTabOne).grid(row=1, column=1, padx=15, pady=15)
        genderEntryTabOne = ttk.Entry(tab1, textvariable=self.genderTabOne).grid(row=2, column=1, padx=15, pady=15)
        hosnameEntryTabOne = ttk.Entry(tab1, textvariable=self.hosnameTabOne).grid(row=4, column=1, padx=15, pady=15)
        hoslocationEntryTabOne = ttk.Entry(tab1, textvariable=self.hoslocationTabOne).grid(row=5, column=1, padx=15, pady=15)

        contents = ["American Native or Alaska Native", "Black or African American", "Asian",
                    "Middle Eastern or North African", "Native Hawaiian or Other Pacific Islander",
                    "White", "Hispanic or Latino"]
        self.optionsVar = tk.IntVar()
        self.optionsVar.set("Select Race/Ethnicity")
        dropdownTabOne = tk.OptionMenu(tab1, self.optionsVar, *contents).grid(row=3, column=1, padx=15, pady=15)
        
        forwardButtonTabOne = tk.Button(tab1, text='Forward', command=self.scroll_forward_tab1).grid(row=6, column=2, padx=15, pady=15)
        backButtonTabOne = tk.Button(tab1, text='Back', command=self.scroll_backward_tab1).grid(row=6, column=0, padx=15, pady=15)


        # Add widgets to tab2 (Manage Tumor Info)
        tissueLabelTabTwo = ttk.Label(tab2, text='Tissue Type').grid(row=0, column=0, padx=15, pady=15)
        mycLabelTabTwo = ttk.Label(tab2, text='MYC Rearrangement').grid(row=1, column=2, padx=15, pady=15)
        bcl2LabelTabTwo = ttk.Label(tab2, text='BCL2 Rearrangement').grid(row=2, column=2, padx=15, pady=15)
        bcl6LabelTabTwo = ttk.Label(tab2, text='BCL6 Rearrangement').grid(row=3, column=2, padx=15, pady=15)
        diagnosisLabelTabTwo = ttk.Label(tab2, text='Diagnosis').grid(row=1, column=0, padx=15, pady=15)
        hosnameLabelTabTwo = ttk.Label(tab2, text='Hospital Name').grid(row=2, column=0, padx=15, pady=15)
        hoslocationLabelTabTwo = ttk.Label(tab2, text='Hospital Location').grid(row=3, column=0, padx=15, pady=15)

        self.tissueTabTwo = tk.StringVar()
        self.mycTabTwo = tk.IntVar()
        self.bcl2TabTwo = tk.IntVar()
        self.bcl6TabTwo = tk.IntVar()
        self.diagnosisTabTwo = tk.StringVar()
        self.hosnameTabTwo = tk.StringVar()
        self.hoslocationTabTwo = tk.StringVar()

        tissueEntryTabTwo = ttk.Entry(tab2, textvariable=self.tissueTabTwo, state="normal").grid(row=0, column=1, padx=15, pady=15)
        mycEntryTabTwo = ttk.Checkbutton(tab2, variable=self.mycTabTwo, onvalue=1, offvalue=0, state="normal").grid(row=1, column=3, padx=15, pady=15)
        bcl2EntryTabTwo = ttk.Checkbutton(tab2, variable=self.bcl2TabTwo, onvalue=1, offvalue=0, state="normal").grid(row=2, column=3, padx=15, pady=15)
        bcl6EntryTabTwo = ttk.Checkbutton(tab2, variable=self.bcl6TabTwo, onvalue=1, offvalue=0, state="normal").grid(row=3, column=3, padx=15, pady=15)
        diagnosisEntryTabTwo = ttk.Entry(tab2, textvariable=self.diagnosisTabTwo, state="normal").grid(row=1, column=1, padx=15, pady=15)
        hosnameEntryTabTwo = ttk.Entry(tab2, textvariable=self.hosnameTabTwo, state="normal").grid(row=2, column=1, padx=15, pady=15)
        hoslocationEntryTabTwo = ttk.Entry(tab2, textvariable=self.hoslocationTabTwo, state="normal").grid(row=3, column=1, padx=15, pady=15)

        forwardButtonTabTwo = tk.Button(tab2, text='Forward', command=self.scroll_forward_tab2).grid(row=4, column=2, padx=15, pady=15)
        backButtonTabTwo = tk.Button(tab2, text='Back', command=self.scroll_backward_tab2).grid(row=4, column=0, padx=15, pady=15)

        # Add widgets to tab3 (Add New Patient)
        ageLabelTabThree = ttk.Label(tab3, text='Patient Age').grid(row=0, column=0, padx=15, pady=15)
        genderLabelTabThree = ttk.Label(tab3, text='Patient Gender').grid(row=1, column=0, padx=15, pady=15)
        demographicLableTabThree = ttk.Label(tab3, text="Race/Ethnicity").grid(row=3, column=0, padx=15, pady=15)
        hosnameLabelTabThree = ttk.Label(tab3, text="Hospital Name").grid(row=4, column=0, padx=15, pady=15)
        hoslocationLabelTabThree = ttk.Label(tab3, text="Hosptial Location\n(ex) Houston, Texas)").grid(row=5, column=0, padx=15, pady=15)

        self.ageTabThree = tk.StringVar()
        self.genderTabThree = tk.StringVar()
        self.hosnameTabThree = tk.StringVar()
        self.hoslocationTabThree = tk.StringVar()

        ageEntryTabThree = ttk.Entry(tab3, textvariable=self.ageTabThree, state="normal").grid(row=0, column=1, padx=15, pady=15)
        genderEntryTabThree = ttk.Entry(tab3, textvariable=self.genderTabThree, state="normal").grid(row=1, column=1, padx=15, pady=15)
        hosnameEntryTabThree = ttk.Entry(tab3, textvariable=self.hosnameTabThree, state="normal").grid(row=4, column=1, padx=15, pady=15)
        hoslocationEntryTabThree = ttk.Entry(tab3, textvariable=self.hoslocationTabThree, state="normal").grid(row=5, column=1, padx=15, pady=15)

        contents = ["American Native or Alaska Native", "Black or African American", "Asian",
                    "Middle Eastern or North African", "Native Hawaiian or Other Pacific Islander",
                    "White", "Hispanic or Latino"]
        self.optionsVarThree = tk.StringVar()
        self.optionsVarThree.set("Select Race/Ethnicity")
        dropdownTabThree = tk.OptionMenu(tab3, self.optionsVarThree, *contents).grid(row=3, column=1, padx=15, pady=15)

        submitButtonTabThree = tk.Button(tab3, text="Submit", command=self.add_new_patient).grid(row=6, column=1, padx=15, pady=15)

        # Add widets to tab4 (Add New Tumor)
        idLabelTabFour = ttk.Label(self.tab4, text='Patient ID').grid(row=0, column=0, padx=15, pady=15)
        tissueLabelTabFour = ttk.Label(self.tab4, text='Tissue Type').grid(row=1, column=0, padx=15, pady=15)
        mycLabelTabFour = ttk.Label(self.tab4, text='MYC Rearrangement').grid(row=0, column=2, padx=15, pady=15)
        bcl2LabelTabFour = ttk.Label(self.tab4, text='BCL2 Rearrangement').grid(row=1, column=2, padx=15, pady=15)
        bcl6LabelTabFour = ttk.Label(self.tab4, text='BCL6 Rearrangement').grid(row=2, column=2, padx=15, pady=15)
        diagnosisLabelTabFour = ttk.Label(self.tab4, text="Diagnosis").grid(row=2, column=0, padx=15, pady=15)

        self.tissueTabFour = tk.StringVar()
        self.mycTabFour = tk.IntVar()
        self.bcl2TabFour = tk.IntVar()
        self.bcl6TabFour = tk.IntVar()
        self.diagnosisTabFour = tk.StringVar()

        tissueEntryTabFour = ttk.Entry(self.tab4, textvariable=self.tissueTabFour, state="normal").grid(row=1, column=1, padx=15, pady=15)
        mycEntryTabFour = ttk.Checkbutton(self.tab4, variable=self.mycTabFour, onvalue=1, offvalue=0, state="normal").grid(row=0, column=3, padx=15, pady=15)
        bcl2EntryTabFour = ttk.Checkbutton(self.tab4, variable=self.bcl2TabFour, onvalue=1, offvalue=0, state="normal").grid(row=1, column=3, padx=15, pady=15)
        bcl6EntryTabFour = ttk.Checkbutton(self.tab4, variable=self.bcl6TabFour, onvalue=1, offvalue=0, state="normal").grid(row=2, column=3, padx=15, pady=15)
        diagnosisEntryTabFour = ttk.Entry(self.tab4, textvariable=self.diagnosisTabFour, state="normal").grid(row=2, column=1, padx=15, pady=15)

        submitButtonTabFour = tk.Button(self.tab4, text="Submit", command=self.add_new_tumor).grid(row=3, column=1, padx=15, pady=15)

        self.patient_var_TabFour = tk.StringVar(self.tab4)
        self.patient_var_TabFour.set("Select Patient ID")

        self.load_db_menu_patient_id()
        self.db_name_dropdown_tab_four = tk.OptionMenu(self.tab4, self.patient_var_TabFour, *self.patient_ids).grid(row=0, column=1, padx=15, pady=15)


        # Add widgets to tab5 (Search Patient/Tumor)
        idLabelTabFive = ttk.Label(self.tab5, text='Patient ID').grid(row=0, column=0, padx=15, pady=15)
        ageLabelTabFive = ttk.Label(self.tab5, text='Patient Age').grid(row=1, column=0, padx=15, pady=15)
        genderLabelTabFive = ttk.Label(self.tab5, text='Patient Gender').grid(row=2, column=0, padx=15, pady=15)
        tissueLabelTabFive = ttk.Label(self.tab5, text='Tissue Type').grid(row=3, column=0, padx=15, pady=15)
        mycLabelTabFive = ttk.Label(self.tab5, text='MYC Rearrangement').grid(row=0, column=2, padx=15, pady=15)
        bcl2LabelTabFive = ttk.Label(self.tab5, text='BCL2 Rearrangement').grid(row=1, column=2, padx=15, pady=15)
        bcl6LabelTabFive = ttk.Label(self.tab5, text='BCL6 Rearrangement').grid(row=2, column=2, padx=15, pady=15)
        diagnosisLabelTabFive = ttk.Label(self.tab5, text="Diagnosis").grid(row=3, column=2, padx=15, pady=15)
        hosnameLabelTabFive = ttk.Label(self.tab5, text='Hospital Name').grid(row=4, column=0, padx=15, pady=15)
        hoslocationLabelTabFive = ttk.Label(self.tab5, text='Hospital Location').grid(row=5, column=0, padx=15, pady=15)
        demographicLabelTabFive = ttk.Label(self.tab5, text="Race/Ethnicity").grid(row=4, column=2, padx=15, pady=15)

        self.idTabFive = tk.StringVar()
        self.ageTabFive = tk.StringVar()
        self.genderTabFive = tk.StringVar()
        self.tissueTabFive = tk.StringVar()
        self.mycTabFive = tk.IntVar()
        self.bcl2TabFive = tk.IntVar()
        self.bcl6TabFive = tk.IntVar()
        self.diagnosisTabFive = tk.StringVar()
        self.hosnameTabFive = tk.StringVar()
        self.hoslocationTabFive = tk.StringVar()
        self.demographicTabFive = tk.StringVar()

        idEntryTabFive = ttk.Entry(self.tab5, textvariable=self.idTabFive, state="normal").grid(row=0, column=1, padx=15, pady=15)
        ageEntryTabFive = ttk.Entry(self.tab5, textvariable=self.ageTabFive, state="normal").grid(row=1, column=1, padx=15, pady=15)
        genderEntryTabFive = ttk.Entry(self.tab5, textvariable=self.genderTabFive, state="normal").grid(row=2, column=1, padx=15, pady=15)
        tissueEntryTabFive = ttk.Entry(self.tab5, textvariable=self.tissueTabFive, state="normal").grid(row=3, column=1, padx=15, pady=15)
        mycEntryTabFive = ttk.Checkbutton(self.tab5, variable=self.mycTabFive, onvalue=1, offvalue=0, state="normal").grid(row=0, column=3, padx=15, pady=15)
        bcl2EntryTabFive = ttk.Checkbutton(self.tab5, variable=self.bcl2TabFive, onvalue=1, offvalue=0, state="normal").grid(row=1, column=3, padx=15, pady=15)
        bcl6EntryTabFive = ttk.Checkbutton(self.tab5, variable=self.bcl6TabFive, onvalue=1, offvalue=0, state="normal").grid(row=2, column=3, padx=15, pady=15)
        hosnameEntryTabFive = ttk.Entry(self.tab5, textvariable=self.hosnameTabFive, state="normal").grid(row=4, column=1, padx=15, pady=15)
        hoslocationEntryTabFive = ttk.Entry(self.tab5, textvariable=self.hoslocationTabFive, state="normal").grid(row=5, column=1, padx=15, pady=15)

        demographiccontents = ["Select Race/Ethnicity", "American Native or Alaska Native", "Black or African American",
                               "Asian",
                               "Middle Eastern or North African", "Native Hawaiian or Other Pacific Islander",
                               "White", "Hispanic or Latino"]
        self.demographicTabFive.set("Select Race/Ethnicity")
        demographicDropdownTabFive = tk.OptionMenu(self.tab5, self.demographicTabFive, *demographiccontents).grid(row=4, column=3, padx=15, pady=15)

        diagnosiscontents = ["Select Diagnosis", "Double Hit Lymphoma", "Triple Hit Lymphoma"]
        self.diagnosisTabFive.set("Select Diagnosis")
        diagnosisDropdownTabFive = tk.OptionMenu(self.tab5, self.diagnosisTabFive, *diagnosiscontents).grid(row=3, column=3, padx=15, pady=15)

        searchButtonTabFive = tk.Button(self.tab5, text="Search", command=self.display_query_results).grid(row=6, column=2, padx=15, pady=15)

        rows = 6
        columns = 3

        for i in range(rows):
            self.tab5.grid_rowconfigure(i, weight=0)

        for i in range(columns):
            self.tab5.grid_columnconfigure(i, weight=0)

        self.tab5.grid_rowconfigure(7, weight=1)
        self.tab5.grid_columnconfigure(0, weight=1) 

        # Add widgets to tab6 (Logout)
        logoutButtonTabSeven = tk.Button(tab6, text='Logout', command=self.exitButtonClicked)
        logoutButtonTabSeven.grid(row=7, column=4, padx=15, pady=15)
        
        tab_parent.pack(expand=1, fill='both')

        self.initial_widget_info()

    def initial_widget_info(self):
        success1 = self.load_patient_info_results()
        if success1:
            self.idTabOne.set(self.rows[0][0])
            self.ageTabOne.set(self.rows[0][1])
            self.genderTabOne.set(self.rows[0][2])
            self.optionsVar.set(self.rows[0][3])
            self.hosnameTabOne.set(self.rows[0][4])
            self.hoslocationTabOne.set(self.rows[0][5])

        success2 = self.load_tumor_info_results()
        if success2:
            self.tissueTabTwo.set(self.rows1[0][1])
            self.diagnosisTabTwo.set(self.rows1[0][2])
            self.hosnameTabTwo.set(self.rows1[0][3])
            self.hoslocationTabTwo.set(self.rows1[0][4])
            if "MYC Rearrangement" in self.rows1[0][5] and "BCL2 Rearrangement" in self.rows1[0][5] and "BCL6 Rearrangement" in self.rows1[0][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[0][5] and "BCL2 Rearrangement" in self.rows1[0][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
            elif "BCL2 Rearrangement" in self.rows1[0][5] and "BCL6 Rearrangement" in self.rows1[0][5]:
                self.mycTabTwo.set(0)
                self.bcl6TabTwo.set(1)
                self.bcl2TabTwo.set(1)
            elif "MYC Rearrangement" in self.rows1[0][5] and "BCL6 Rearrangement" in self.rows1[0][5]:
                self.mycTabTwo.set(1)
                self.bcl2TabTwo.set(0)
                self.bcl6TabTwo.set(1)
            elif self.rows1[0][5] == "MYC Rearrangement":
                self.mycTabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.bcl2TabTwo.set(0)
            elif self.rows1[0][5] == "BCL2 Rearrangement":
                self.bcl2TabTwo.set(1)
                self.bcl6TabTwo.set(0)
                self.mycTabTwo.set(0)
            elif self.rows1[0][5] == "BCL6 Rearrangement":
                self.bcl6TabTwo.set(1)
                self.mycTabTwo.set(0)
                self.bcl2TabTwo.set(0)


    #def grab_tumor(self):
        # grab the tumor info
        #self.master.tumor_list.append(self.tumor_info)



# Create a class to keep track of widgets and their states
class MainApplication(tk.Tk):

    def __init__(self):
        super().__init__()           
        self.geometry("800x600")
        self.current_frame = None
        self.rows = None
        self.rows1 = None
        self.num_of_rows = None
        self.row_counter = 0
        self.blank_textboxes_tab_three = True
        self.blank_textboxes_tab_four = True
    

        self.switch_frame(LoginFrame)

    def switch_frame(self, new_frame_class, tab_parent=None):
        new_frame = new_frame_class(self)
        
        if tab_parent is not None:
            #for widget in tab_parent.winfo_children():
                #widget.destroy()   
            tab_parent.destroy()
             

        if self.current_frame is not None:
            #self.current_frame.destroy()
            for widget in self.current_frame.winfo_children(): 
                widget.destroy()

        elif self.current_frame is None and self.current_frame != new_frame: 
            self.current_frame = new_frame
        self.current_frame = new_frame
        #self.current_frame.pack()

    def database_error(self, err):
        messagebox.showinfo("Error", err)
        return False

    def insert_database(self, con, sql, vals):
        try:
            cursor = con.cursor()
            cursor.execute(sql, vals)
            con.commit()
        except pymysql.ProgrammingError as e:
            self.database_error(e)
        except pymysql.DataError as e:
            self.database_error(e)
        except pymysql.IntegrityError as e:
            self.database_error(e)
        except pymysql.NotSupportedError as e:
            self.database_error(e)
        except pymysql.OperationalError as e:
            self.database_error(e)
        except pymysql.InternalError as e:
            self.database_error(e)


    


if __name__ == "__main__":
     app = MainApplication()
     app.mainloop()
